package com.clydeev.scraper.douayrheims;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

/**
 *
 * @author cvelasquez
 */
public class Scraper {

	private String proxy;
	private int port;

	public Scraper(String proxy, int port) {
		this.proxy = proxy;
		this.port = port;
	}

	public void scrape() {
		boolean hasNextChapter;
		String url = "http://catholicbible.online/douay_rheims/OT";
		Document doc;

		try {
			doc = Jsoup.connect(url)
					.proxy(proxy, port)
					.timeout((int) TimeUnit.MINUTES.toMillis(1))
					.get();

			Elements books = doc.select("ul[class^=item-list] li[class^=book-item]");
			int noOfBooks = books.size();
			for (int i = 0; i < noOfBooks; i++) {
				
				url = books.get(i).selectFirst("a").attr("href");
						
				do { // Loop per chapter
					try {
						doc = Jsoup.connect(url)
								.proxy(proxy, port)
								.timeout((int) TimeUnit.MINUTES.toMillis(2))
								.get();

						String bookName = doc.selectFirst("li[class=book-item active]").text();
						String chapter = doc.selectFirst("div[class=chapter]").text();

						StringBuilder sb = new StringBuilder();
						sb.append("Title: ").append(doc.selectFirst("div[class=book-name]").text()).append("\n");
						sb.append(chapter).append("\n");
						doc.select("div[class=vers]").forEach(verse -> sb.append(verse.text()).append("\n"));

						FileUtils.writeStringToFile(new File("/home/cvelasquez/Desktop/Books/DouayRheims/OT/" + bookName + "/" + chapter + ".txt"),
								sb.toString(), "UTF-8");
					} catch (IOException ex) {
						Logger.getLogger(Scraper.class.getName()).log(Level.SEVERE, null, ex);
					} finally {
						try {
							url = doc.selectFirst("div[class=next-chapter] a").attr("href");
							hasNextChapter = url != null;
						} catch (NullPointerException e) {
							hasNextChapter = false;
						}
					}
				} while (hasNextChapter);
			}
		} catch (IOException ex) {
			Logger.getLogger(Scraper.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}