package com.clydeev.scraper.douayrheims;

/**
 *
 * @author cvelasquez
 */
public class Main {
	
	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.gecko.driver", "/home/cvelasquez/NetBeansProjects/SeleniumScraper/geckodriver");
		System.setProperty("webdriver.chrome.driver", "/home/cvelasquez/NetBeansProjects/SeleniumScraper/chromedriver");
		
		Scraper scraper = new Scraper("192.168.20.206", 3128);
		scraper.scrape();
		
		NotesScraper notes = new NotesScraper();
		notes.scrape();
	}
}
