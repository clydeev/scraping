package com.clydeev.scraper.test;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.junit.Ignore;
import org.junit.Test;

/**
 *
 * @author cvelasquez
 */
public class ScraperTest {
	
	@Test
	@Ignore
	public void accessHomePage() throws IOException {
		Document home = Jsoup.connect("http://catholicbible.online/douay_rheims/OT").proxy("10.10.11.204", 3128).get();
		FileUtils.writeStringToFile(new File("/home/cvelasquez/Desktop/Scrape/OT/index.html"), home.html(), "UTF-8");
	}
	
	@Test
	public void bookList() throws IOException {
		File index = new File("/home/cvelasquez/Desktop/index.html");
		Document doc = Jsoup.parse(index, "UTF-8");
		doc.select("ul[class^=item-list] li[class^=book-item]")
				.forEach(li -> System.out.println(li.text() + "=" + li.html() + " " + li.select("a").attr("href")));
		
		
		int noOfBooks = doc.select("ul[class^=item-list] li[class^=book-item]").size();
		
//		for (int i = 0; i < noOfBooks; i++) {
//			System.out.println(books.get(i).selectFirst("a"));
//		}
	}
}
